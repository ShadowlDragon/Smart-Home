import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="kyle",
  password="123456",
  database="smart_home"
)

